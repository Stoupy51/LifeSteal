
#> life_steal:v2.3.1/load/enumerate
#
# @within	#life_steal:enumerate
#

# If current major is too low, set it to the current major
execute unless score #life_steal.major load.status matches 2.. run scoreboard players set #life_steal.major load.status 2

# If current minor is too low, set it to the current minor (only if major is correct)
execute if score #life_steal.major load.status matches 2 unless score #life_steal.minor load.status matches 3.. run scoreboard players set #life_steal.minor load.status 3

# If current patch is too low, set it to the current patch (only if major and minor are correct)
execute if score #life_steal.major load.status matches 2 if score #life_steal.minor load.status matches 3 unless score #life_steal.patch load.status matches 1.. run scoreboard players set #life_steal.patch load.status 1

