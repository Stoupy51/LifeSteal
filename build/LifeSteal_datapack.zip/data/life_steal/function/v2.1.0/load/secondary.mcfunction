
#> life_steal:v2.1.0/load/secondary
#
# @within	life_steal:v2.1.0/load/main
#

# LifeSteal
scoreboard objectives add life_steal.data dummy
tag Stoupy51 add convention.debug

# Confirm load
function life_steal:v2.1.0/load/confirm_load

