
#> life_steal:calls/smithed_crafter/shaped_recipes
#
# @within	#smithed.crafter:event/recipes
#

execute if score @s smithed.data matches 0 store result score @s smithed.data if data storage smithed.crafter:input recipe{0:[{"Slot":0b, "id": "minecraft:trial_key"},{"Slot":1b, "id": "minecraft:ghast_tear"},{"Slot":2b, "id": "minecraft:trial_key"}],1:[{"Slot":0b, "id": "minecraft:ghast_tear"},{"Slot":1b, "id": "minecraft:ender_eye"},{"Slot":2b, "id": "minecraft:ghast_tear"}],2:[{"Slot":0b, "id": "minecraft:trial_key"},{"Slot":1b, "id": "minecraft:ghast_tear"},{"Slot":2b, "id": "minecraft:trial_key"}]} run function life_steal:calls/smithed_crafter/apply_recipe {"command":"loot replace block ~ ~ ~ container.16 loot life_steal:i/crafted_heart"}
execute if score @s smithed.data matches 0 store result score @s smithed.data if data storage smithed.crafter:input recipe{0:[{"Slot":0b, "id": "minecraft:beacon"},{"Slot":1b, "id": "minecraft:elytra"},{"Slot":2b, "id": "minecraft:beacon"}],1:[{"Slot":0b, "id": "minecraft:recovery_compass"},{"Slot":1b, "id": "minecraft:heavy_core"},{"Slot":2b, "id": "minecraft:conduit"}],2:[{"Slot":0b, "id": "minecraft:beacon"},{"Slot":1b, "id": "minecraft:skeleton_skull"},{"Slot":2b, "id": "minecraft:beacon"}]} run function life_steal:calls/smithed_crafter/apply_recipe {"command":"loot replace block ~ ~ ~ container.16 loot life_steal:i/revive_beacon"}

