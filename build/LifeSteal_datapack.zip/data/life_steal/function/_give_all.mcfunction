
#> life_steal:_give_all
#
# @within	???
#

give @s chest[container=[{slot:0,item:{count:1,id:"minecraft:command_block",components:{"damage_resistant": {"types": "#life_steal:is_explosion_or_fire"},"consumable": {},"item_model": "life_steal:heart","item_name": {"text": "Heart"},"lore": [["",{"text": "I","color": "white","italic": false,"font": "life_steal:icons"},{"text": " LifeSteal","italic": true,"color": "blue"}]],"custom_data": {"life_steal": {"heart": true},"smithed": {"ignore": {"functionality": true,"crafting": true}}}}}},{slot:1,item:{count:1,id:"minecraft:command_block",components:{"consumable": {},"lore": [{"text": "Rename the item to the username","italic": false,"color": "gray"},{"text": "of the player you want to revive.","italic": false,"color": "gray"},["",{"text": "I","color": "white","italic": false,"font": "life_steal:icons"},{"text": " LifeSteal","italic": true,"color": "blue"}]],"item_model": "life_steal:revive_beacon","item_name": {"text": "Revive Beacon"},"custom_data": {"life_steal": {"revive_beacon": true},"smithed": {"ignore": {"functionality": true,"crafting": true}}}}}}],custom_name={"text":"Chest [1/1]","color":"yellow"},lore=[["",{"text": "I","color": "white","italic": false,"font": "life_steal:icons"},{"text": " LifeSteal","italic": true,"color": "blue"}]]]

