
#> life_steal:v2.5.1/load/secondary
#
# @within	life_steal:v2.5.1/load/main
#

# LifeSteal
scoreboard objectives add life_steal.data dummy
tag Stoupy51 add convention.debug

# Confirm load
function life_steal:v2.5.1/load/confirm_load

