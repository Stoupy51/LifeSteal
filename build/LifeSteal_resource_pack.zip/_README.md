
## merge/resource_pack folder
Every file and subfolders will be merged to the build resource_pack folder.

